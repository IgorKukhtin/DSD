#Requires -RunAsAdministrator

$DisplayName = "eSign integration client" 
$Description = "eSign integration client" 
$Path = $PSScriptRoot
$Exe = "eSign.Signer.Integration.Client.exe"
$login = 'NT AUTHORITY\NETWORK SERVICE'

$secpasswd = (new-object System.Security.SecureString)
$cred = New-Object System.Management.Automation.PSCredential ($login, $secpasswd)


$acl = Get-Acl $Path
$aclRuleArgs = $cred.UserName, "Read,Write,ReadAndExecute", "ContainerInherit, ObjectInherit", "None", "Allow"
$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule $aclRuleArgs
$acl.SetAccessRule($accessRule)
$acl | Set-Acl $Path

New-Service -Name 'eSignIntegration' -BinaryPathName "$Path\$Exe" -Credential $cred -Description $Description -DisplayName $DisplayName -StartupType Automatic
