#Requires -RunAsAdministrator

$service = Get-WmiObject -Class Win32_Service -Filter "Name='eSignIntegration'"
$service.delete()