
$serviceName = 'eSignIntegration'

If (-Not (Get-Service $serviceName -ErrorAction SilentlyContinue)) {
	& "$PSScriptRoot\RegisterService.ps1"
}


Start-Service -Name $serviceName